---
title: ''
exclude: true
readingTime: false
---

<style>
    .friend-links {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
        gap: 20px;
        padding: 20px;
    }
</style>

## 友情链接

<section class="friend-links">
    <!-- See layouts/head/custom.html for element definition  -->
    <friendly-link src="https://wsdjeg.net/" title="Eric's blog" desc="时光荏苒，岁月如梭"></friendly-link>
</section>

## 交换友链

交换友链可以发[邮件](mailto:shaobin-jiang@outlook.com?subject=交换友链)联系我。

本站的友链信息：

> 站点名称：姜绍彬的博客
>
> 站点地址：https://shaobin-jiang.github.io/blog/
>
> 站点头像：https://shaobin-jiang.github.io/blog/favicon.ico
>
> 站点描述：聊聊技术
